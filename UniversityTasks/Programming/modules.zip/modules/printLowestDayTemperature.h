#ifndef MODULES_PRINTLOWESTDAYTEMPERATURE_H
#define MODULES_PRINTLOWESTDAYTEMPERATURE_H

void printLowestDayTemperature(float **array, int days, int measurements);

#endif //MODULES_PRINTLOWESTDAYTEMPERATURE_H
