
#ifndef MODULES_GETAVERAGEFORTHEMONTH_H
#define MODULES_GETAVERAGEFORTHEMONTH_H

float getAverageForTheMonth(float **array, int days, int measurements);

#endif //MODULES_GETAVERAGEFORTHEMONTH_H
