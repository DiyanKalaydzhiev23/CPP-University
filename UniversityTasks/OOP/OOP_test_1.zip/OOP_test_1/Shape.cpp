#include "Shape.h"

Shape::Shape() {
    this -> edges = 0;
}

Shape::Shape(int edges) {
    this -> edges = edges;
}