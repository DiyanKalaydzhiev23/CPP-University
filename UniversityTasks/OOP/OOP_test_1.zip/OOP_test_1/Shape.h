#ifndef OOP_TEST_1_SHAPE_H
#define OOP_TEST_1_SHAPE_H


class Shape {
    public:
        Shape();
        explicit Shape(int edges);

    private:
        int edges;
};


#endif //OOP_TEST_1_SHAPE_H
